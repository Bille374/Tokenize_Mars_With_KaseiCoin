# Tokenize_Mars_With_KaseiCoin

As ay Fintech developer, developing a new monetery system for new colony.
implementing the new system on blockchain technology, define a new cryptocurrency, named KaseiCoin. 

# The Goal:
launch a crowdsale for people moving to Mars
Coverting their earthing money to KaseiCoin.

Kai coin is a fungible tokens as the dollar has the same value no matter where you go runs on ERC20 Ethereum network

# CrowdSale Contract:

user send their Ether to receive KAi, Contract Automatically mint tokens and disttribute them to buyers in one transaction.

# Implementation By Using JS VM
First,By Creating the first Contract KaseiCoin.sol and by importing OpenZeppelin library  make our job easier by only call the constructor()
then define different varaiable in it.

![1](https://user-images.githubusercontent.com/69637182/201227238-9b787b0d-b4fb-4b7c-9e32-29e1c45476ab.png)

Secondly, Creat another contract called Crowdsale.sol and inherit kaseiCoin and library
This part is the most chanllenging one because it splits in two contract, the ployer contract one we get the address will be filled in crowdsale wallet with that will get our rate, token and wallet adresss for crowdsale.

![Screenshot 2022-11-10 170057](https://user-images.githubusercontent.com/69637182/201228565-51c64b3f-0d5d-416c-863c-37d74c51f415.png)
![Screenshot 2022-11-10 170119](https://user-images.githubusercontent.com/69637182/201228579-de8901b6-a4f8-42eb-802f-9137558657d8.png)
![Screenshot 2022-11-10 170037](https://user-images.githubusercontent.com/69637182/201228590-6bc8fb4f-cd91-42e3-bc5f-9b67859c914a.png)

Thirdly, from screen shots we can tell our contracts got deployed withour any errors
![Final](https://user-images.githubusercontent.com/69637182/201229532-66dbadc5-0ea3-43c4-ac83-254039b1cd76.png)

# Conclusion
Mission from Earth to Mars 
![th_1](https://user-images.githubusercontent.com/69637182/201230236-ef7147ff-6bde-4da2-8183-7cf62b2163ba.png)



